from django.contrib import admin

from shop.models import Item

# Register your models here.
admin.site.register(Item)
